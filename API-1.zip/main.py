import pandas as pd
from flask import Flask, jsonify

app = Flask (__name__)

@app.route('/homepage')
def homepage():
  return 'Homepage do site'

@app.route('/contatos')
def contatos():
  return 'Contatos do site'

@app.route('/sum/<int:a>/<int:b>')
def sum(a,b):
  return {a + b}
  

@app.route('/pegarvendas')
def pegarvendas():
  table = pd.read_csv('tabela.csv')
  total_vendas = table['Vendas'].sum()
  print(total_vendas)
  resposta = {'total_vendas': total_vendas}
  return (resposta)

  
app.run(host='0.0.0.0')
                       